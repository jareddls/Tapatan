import React from 'react'
import Tapatan from '../components/Tapatanv2'

const RandomMove = () => {
  return (
    <div className='centered'>
        <Tapatan logic="random_move"/>
    </div>
  )
}

export default RandomMove