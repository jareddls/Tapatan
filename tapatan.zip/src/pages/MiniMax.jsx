import React from 'react'
import Tapatan from '../components/Tapatanv2'

const MiniMax = () => {
  return (
    <div className='centered'>
        <Tapatan logic="minimax"/>
    </div>
  )
}

export default MiniMax